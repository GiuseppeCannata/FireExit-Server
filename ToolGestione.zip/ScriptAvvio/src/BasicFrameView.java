import javax.swing.*;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import static com.sun.glass.ui.Cursor.setVisible;

public class BasicFrameView extends JFrame{

    private JPanel panel1;
    private JScrollPane scrPanel;
    Pannello pannello;
    /*COSTRUTTORE*/
    public BasicFrameView(){

        super("Tool gestione");

        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setSize(600, 600);
        setLocation(250, 100);
        setContentPane(panel1);
        Image icon = Toolkit.getDefaultToolkit().getImage("fireexit.png");
        setIconImage(icon);
        setResizable(false);
        setVisible(true);
        pannello = new Pannello();
        scrPanel.setViewportView(pannello.getIntermedioO());

        addWindowListener (new WindowAdapter() {
            public void windowClosing (WindowEvent e) {
                if( JOptionPane.showConfirmDialog (BasicFrameView.this, "Server e DB verrano spenti se accesi. Continuare?", "Warning",
                        JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE)  == JOptionPane.YES_OPTION  ){
                    if(pannello.DBON==1)
                       spegniDB();
                    if(pannello.ServerON==1)
                        spegniServer();

                    System.exit(0);
                }
            }
        });
    }

    private void spegniDB(){

        String[] command = new String[3];
        command[0] = "cmd";
        command[1] = "/c";
        command[2] = "cd .\\glassfish\\bin\\&& asadmin stop-database";
        try {

            Process p = Runtime.getRuntime().exec(command);

        } catch (Exception ev) {
            System.out.println("Qualcosa è andato storto: " + ev.toString());
        }
    }

    private void spegniServer(){
        String[] command = new String[3];
        command[0] = "cmd";
        command[1] = "/c";
        command[2] = "cd .\\glassfish\\bin\\&& asadmin stop-domain domain1";

        try {
            Process p = Runtime.getRuntime().exec(command);

        } catch (Exception ev) {
            System.out.println("Qualcosa è andato storto: " + ev.toString());
        }
    }
}