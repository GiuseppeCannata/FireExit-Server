import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

public class Pannello extends JPanel {

    private JButton AvviaServerButton;
    private JButton avviaDBButton;
    private JButton stopServerButton;
    private JButton stopDBButton1;
    private JPanel IntermedioO;
    private JTextArea textArea1;

    private StreamGobbler outputGobbler;

    public int ServerON=0;
    public int DBON=0;

    public JPanel getIntermedioO() {
        return IntermedioO;
    }

    public Pannello()  {

        setVisible(true);
        Finestra f = new Finestra();

        AvviaServerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {


                String[] command = new String[3];
                command[0] = "cmd";
                command[1] = "/c";
                command[2] = "cd .\\glassfish\\bin\\&& asadmin start-domain domain1";

                try {
                    Process p = Runtime.getRuntime().exec(command);
                    //controlloTH(p.getInputStream());
                    outputGobbler = new StreamGobbler(p.getInputStream(), textArea1);
                    outputGobbler.start();
                    ServerON=1;
                    f.visibile(true);
                    p.waitFor();
                    f.visibile(false);
                    stopServerButton.setVisible(true);
                    AvviaServerButton.setVisible(false);

                } catch (Exception ev) {
                    System.out.println("Qualcosa è andato storto: " + ev.toString());
                }
            }
        });


        stopServerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String[] command = new String[3];
                command[0] = "cmd";
                command[1] = "/c";
                command[2] = "cd .\\glassfish\\bin\\&& asadmin stop-domain domain1";

                try {
                    Process p = Runtime.getRuntime().exec(command);
                    outputGobbler = new StreamGobbler(p.getInputStream(), textArea1);
                    outputGobbler.start();
                    ServerON=0;
                    f.visibile(true);
                    p.waitFor();
                    f.visibile(false);
                    stopServerButton.setVisible(false);
                    AvviaServerButton.setVisible(true);

                } catch (Exception ev) {
                    System.out.println("Qualcosa è andato storto: " + ev.toString());
                }

            }
        });

        avviaDBButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String curDir = System.getProperty("user.dir");

                String[] command = new String[3];
                command[0] = "cmd";
                command[1] = "/c";
                command[2] = "cd .\\glassfish\\bin\\&& asadmin start-database --dbhome "+curDir+"\\javadb\\bin";

                try {
                    Process p = Runtime.getRuntime().exec(command);
                    //controlloTH(p.getInputStream());
                    outputGobbler = new StreamGobbler(p.getInputStream(), textArea1);
                    outputGobbler.start();
                    DBON=1;
                    f.visibile(true);
                    p.waitFor();
                    f.visibile(false);
                    stopDBButton1.setVisible(true);
                    avviaDBButton.setVisible(false);


                }catch(IOException e1){
                        e1.printStackTrace();
                        System.out.println("Qualcosa è andato storto: " + e1.toString());
                } catch (InterruptedException e1) {
                    e1.printStackTrace();
                }
            }
        });

        stopDBButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String[] command = new String[3];
                command[0] = "cmd";
                command[1] = "/c";
                command[2] = "cd .\\glassfish\\bin\\&& asadmin stop-database";
                try {

                    Process p = Runtime.getRuntime().exec(command);
                    outputGobbler = new StreamGobbler(p.getInputStream(), textArea1);
                    outputGobbler.start();
                    DBON=0;
                    f.visibile(true);
                    p.waitFor();
                    f.visibile(false);
                    stopDBButton1.setVisible(false);
                    avviaDBButton.setVisible(true);

                } catch (Exception ev) {
                    System.out.println("Qualcosa è andato storto: " + ev.toString());
                }

            }
        });
    }

    class StreamGobbler extends Thread {
        InputStream is;
        JTextArea ta;

        // reads everything from is until empty.
        StreamGobbler(InputStream is,JTextArea textArea1) {
            this.is = is;
            this.ta = textArea1;
        }

        public void run() {
            try {

                InputStreamReader isr = new InputStreamReader(is);
                BufferedReader br = new BufferedReader(isr);
                String line=null;
                while ( (line = br.readLine()) != null) {
                    textArea1.append(line+"\n");
                    System.out.println(line+"\n");
                }

            } catch (IOException ioe) {
                ioe.printStackTrace();
            }
        }
    }
}
