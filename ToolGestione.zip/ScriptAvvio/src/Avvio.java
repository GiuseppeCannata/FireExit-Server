

public class Avvio {

        public static void main (String args[]) {

           new BasicFrameView();
        }
}
