import javax.swing.*;
import java.awt.*;

public class Finestra extends JFrame {

    public static final int LARGHEZZA = 250;
    public static final int ALTEZZA = 150;


    public Finestra() {

        super("Caricamento");
        Image icon = Toolkit.getDefaultToolkit().getImage("fireexit.png");
        setIconImage(icon);
        add(new Label("                 Attendere caricamento in corso .."));
        setBounds(0, 0, LARGHEZZA, ALTEZZA);
        setResizable(false);
        setLocation(400,300);

    }

    public void visibile(boolean enable) {
        setVisible(enable);
    }
}