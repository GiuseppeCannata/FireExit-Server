
# *************************************************************************
# ***              NON MODIFICARE I FILE IN QUESTA DIRECTORY                ***
# *** I FILE DI QUESTA DIRECTORY E DELLE RELATIVE SOTTODIRECTORY     ***
# *** COSTITUISCONO IL DATABASE DERBY, CHE INCLUDE I DATI (UTENTE     ***
# *** E SISTEMA) NONCHÉ I FILE NECESSARI PER IL RECUPERO DEL DATABASE.     ***
# *** LA MODIFICA, L'AGGIUNTA O L'ELIMINAZIONE DEI FILE PUÒ DANNEGGIARE     ***
# *** I DATI E LASCIARE IL DATABASE IN UNO STATO NON RECUPERABILE.     ***
# *************************************************************************